import { PanelCtrl } from './separator.panel.controller';

export { PanelCtrl };
