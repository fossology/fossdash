## Mx's separator panel

It's a simple separator and "It just works" - Todd Howard 2015

Just add it to your current dashboard and enjoy some vertical spacing, like every Grafana plugin you can resize and move it as you wish.

It becomes transparent after you add it and It becomes visible on hover after 300ms with a 150ms transition.

![Example GIF](https://media.giphy.com/media/2ywOVaxWIlGINCfTFS/giphy.gif)
